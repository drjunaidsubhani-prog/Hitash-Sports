Works on Android 5.1 (API 22) and newer.

Build the APK
1. Install Android Studio (free).
2. File > Open > select this HitashApp folder. Let Gradle sync finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The APK is in app/build/outputs/apk/debug/app-debug.apk. Copy it to your phone and install.
For Play Store: Build > Generate Signed Bundle / APK.
To change content: edit app/src/main/assets/index.html (CONTACT block near the end).
